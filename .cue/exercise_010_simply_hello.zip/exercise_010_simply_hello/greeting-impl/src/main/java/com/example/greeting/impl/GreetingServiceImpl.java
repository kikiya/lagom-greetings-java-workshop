/*
 * Copyright (C) 2016 Lightbend Inc. <http://www.lightbend.com>
 */
package com.example.greeting.impl;

import akka.NotUsed;
import com.example.greeting.api.GreetingService;
import com.example.greeting.impl.GreetingCommand.Hello;
import com.lightbend.lagom.javadsl.api.ServiceCall;
import com.lightbend.lagom.javadsl.persistence.PersistentEntityRef;
import com.lightbend.lagom.javadsl.persistence.PersistentEntityRegistry;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;

/**
 * Implementation of the GreetingService.
 */
public class GreetingServiceImpl implements GreetingService {

    private final PersistentEntityRegistry persistentEntityRegistry;

    @Inject
    public GreetingServiceImpl(PersistentEntityRegistry persistentEntityRegistry) {
        this.persistentEntityRegistry = persistentEntityRegistry;

        persistentEntityRegistry.register(GreetingEntity.class);
    }

    @Override
    public ServiceCall<NotUsed, String> hello(String id) {
        return request -> {
            // Look up the hello world entity for the given ID.
            PersistentEntityRef<GreetingCommand> ref = persistentEntityRegistry.refFor(GreetingEntity.class, id);
            //TODO Erase the following line and instead Ask the entity the read-only Hello command.
            return CompletableFuture.completedFuture("you should use the read-only command to greet " + id + " with the current " +
                            "state greeting. *hint* use the Ask method with ref");
        };
    }
}
