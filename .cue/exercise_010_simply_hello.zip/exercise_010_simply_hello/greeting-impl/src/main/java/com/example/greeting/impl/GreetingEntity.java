/*
 * Copyright (C) 2016 Lightbend Inc. <http://www.lightbend.com>
 */
package com.example.greeting.impl;

import com.example.greeting.impl.GreetingCommand.Hello;
import com.lightbend.lagom.javadsl.persistence.PersistentEntity;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * This is an event sourced entity. It has a state, {@link GreetingState}, which
 * stores what the greeting should be (eg, "Hello").
 * <p>
 * Event sourced entities are interacted with by sending them commands. This
 * entity supports one command, a {@link Hello} command, which is a read
 * only command which returns a greeting to the name specified by the command.
 *
 * As this is a read-only command, no events are generated.
 * <p>
 *
 */
public class GreetingEntity extends PersistentEntity<GreetingCommand, GreetingEvent, GreetingState> {

    /**
     * An entity can define different behaviours for different states, but it will
     * always start with an initial behaviour. This entity only has one behaviour.
     */
    @Override
    public Behavior initialBehavior(Optional<GreetingState> snapshotState) {

    /*
     * Behaviour is defined using a behaviour builder. The behaviour builder
     * starts with a state, if this entity supports snapshotting (an
     * optimisation that allows the state itself to be persisted to combine many
     * events into one), then the passed in snapshotState may have a value that
     * can be used.
     *
     * Otherwise, the default state is to use the Hello greeting.
     */
        BehaviorBuilder b = newBehaviorBuilder(
                snapshotState.orElse(new GreetingState("Hello", LocalDateTime.now().toString())));

    /*
     * Command handler for the Hello command.
     */
        b.setReadOnlyCommandHandler(Hello.class,
                // Get the greeting from the current state, and prepend it to the name
                // that we're sending
                // a greeting to, and reply with that message.
                (cmd, ctx) -> ctx.reply(state().message + ", " + cmd.name + "!"));

    /*
     * We've defined all our behaviour, so build and return it.
     */
        return b.build();
    }

}
