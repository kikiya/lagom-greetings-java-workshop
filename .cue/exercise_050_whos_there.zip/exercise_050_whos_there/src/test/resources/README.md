exercise_050_whos_there

## Exercise 050 > Who's There?

### How do we asynchronously consume information from another service withing directly asking?

* We care about special people. Let’s create a new Micro Service, “whosthere” aka the VIP concierge. 
* It wants to know who is there…aka who has insisted on creating custom greetings. Personal greetings. 


