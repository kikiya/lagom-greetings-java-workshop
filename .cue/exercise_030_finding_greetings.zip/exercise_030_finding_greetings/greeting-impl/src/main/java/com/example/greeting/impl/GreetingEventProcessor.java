package com.example.greeting.impl;

import akka.Done;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.lightbend.lagom.javadsl.persistence.AggregateEventTag;
import com.lightbend.lagom.javadsl.persistence.ReadSideProcessor;
import com.lightbend.lagom.javadsl.persistence.cassandra.CassandraReadSide;
import com.lightbend.lagom.javadsl.persistence.cassandra.CassandraSession;
import org.pcollections.PSequence;

import javax.inject.Inject;
import java.util.List;
import java.util.concurrent.CompletionStage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.lightbend.lagom.javadsl.persistence.cassandra.CassandraReadSide.completedStatement;

public class GreetingEventProcessor extends ReadSideProcessor<GreetingEvent> {

    private final Logger log = LoggerFactory.getLogger(GreetingEventProcessor.class);

    private final CassandraSession session;
    private final CassandraReadSide readSide;

    private PreparedStatement writeGreetings = null; // initialized in prepare


    @Inject
    public GreetingEventProcessor(CassandraSession session, CassandraReadSide readSide) {
        this.session = session;
        this.readSide = readSide;
    }

    private void setWriteGreetings(PreparedStatement writeGreetings) {
        this.writeGreetings = writeGreetings;
    }

    @Override
    public ReadSideHandler<GreetingEvent> buildHandler() {
        /**
         * TODO: there's actually a bit more to do here. The builder should use
         *       the methods below to complete this builder
         *       HINT: you will need to use set the Global Prepare,
         *       instance prepare, and the event handler
         */
        return readSide.<GreetingEvent>builder("hello_offset").build();
    }

    @Override
    public PSequence<AggregateEventTag<GreetingEvent>> aggregateTags() {
        return GreetingEvent.TAG.allTags();
    }

    private CompletionStage<Done> prepareCreateTables() {
        // @formatter:off
        return session.executeCreateTable(
                "CREATE TABLE IF NOT EXISTS greeting ("
                        + "id text, message text, "
                        + "PRIMARY KEY (id, message))");
        // @formatter:on
    }

    private CompletionStage<Done> prepareWriteGreetings() {
        return session.prepare("INSERT INTO greeting (id, message) VALUES (?, ?)").thenApply(ps -> {
            setWriteGreetings(ps);
            return Done.getInstance();
        });
    }

    private CompletionStage<List<BoundStatement>> processGreetingMessageChanged(GreetingEvent.GreetingMessageChanged event) {
        log.debug("********************** EventProcessor like: "+event);
        BoundStatement bindWriteGreetings = writeGreetings.bind();
        bindWriteGreetings.setString("id", event.name);
        bindWriteGreetings.setString("message", event.message);
        return completedStatement(bindWriteGreetings);
    }
}