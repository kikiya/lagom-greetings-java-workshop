exercise_000_initial_state

## Exercise 000 > Initial State

This exercise demonstrates a completely stateless service. The simplest type. 

This service should greet guests using the name passed into the URI parameters. 

GET localhost:9000/api/hello/bob 

should respond with 

"Hello, bob!"


*Hint: Changes should happen in "GreetingServiceImpl"*


