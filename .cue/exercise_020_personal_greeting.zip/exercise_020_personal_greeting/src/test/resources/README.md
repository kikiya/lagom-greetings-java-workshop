exercise_020_personal_greeting

## Exercise 020 > Personal Greeting

### How do you update the greeting state to use a personal greeting? 

* In this activity, we will update the project to use a command to change the greeting state. We will add new command (UseGreeting), and add behavior for commands
* Since the new command actually changes the state, we should generate 
events to represent this. We'll add new event “GreetingMessageChanged” 
which will be persisted and used in the future if state needs to be recovered. 
* Tasks
    * Update the builder with command and event handlers
    * Update the impl to use the new entity command


